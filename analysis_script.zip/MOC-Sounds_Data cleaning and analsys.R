##packages #####
install.packages(c(
  "broom", "car", "caret", "plyr", "psych", "tidyverse", "dplyr",
  "reshape2", "qwraps2", "devtools", "tidytext", "rstatix", "fmsb",
  "rcompanion", "afex", "cowplot", "dotwhisker", "GGally", "ggeffects",
  "gridExtra", "ggpubr", "jtools", "sjPlot", "effects", "latticeExtra",
  "corrplot", "RColorBrewer", "jcolors", "plotly", "gplots", "ggthemes",
  "ggstance", "ez", "readxl", "wesanderson"
))

library(broom)
library(car)
library(caret)
library(plyr)
library(psych)
library(tidyverse)
library(dplyr)
library(reshape2)
library(qwraps2) 
library(devtools)
library(tidytext)
library(rstatix)
library(fmsb)
library(rcompanion)
library(afex)
#for plotting
library(cowplot)
library(dotwhisker)
library(GGally)
library(ggeffects)
library(gridExtra)
library(ggpubr)
library(jtools)
library(sjPlot)
library(effects)
library(latticeExtra)
library(corrplot)
library(RColorBrewer)
library(jcolors)
library(plotly)
library(gplots)
library(ggthemes)
library(ggstance)
library(ez)
library(readxl)
library(wesanderson)

####data cleaning####
#set your working directory
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOCOS-sound\\raw_label_and_images")
#import csv
temp = list.files(pattern="*.csv")
for (i in 1:length(temp)) assign(temp[i], read.csv(temp[i]))
objs <- mget(ls(envir = globalenv()))
dfs <- objs[map_lgl(objs, is.data.frame)]

merged <- reduce(dfs, full_join)
merged$participant <- as.factor(merged$participant)

table(merged$participant)

#clean dataset - select  relevant variables for DEMOGRAPHIC 
cols <- c('participant', 'r_sex.response', 'r_vision.response', 'r_audition.response', 'r_age.text',
          'r_education.response', 'r_leveledu.response')
m_demo <- merged[cols]
#remove duplicate columns and NA columns 
m_demo2 <- m_demo[!duplicated(m_demo), ]
m_demo3 <- m_demo2[complete.cases(m_demo2),]
levels(m_demo3$participant)             

#rename columns
colnames(m_demo3)[1] <- 'ID'
colnames(m_demo3)[2] <- 'sex'
colnames(m_demo3)[3] <- 'normal_vision'
colnames(m_demo3)[4] <- 'normal_hearing'
colnames(m_demo3)[5] <- 'age'
colnames(m_demo3)[6] <- 'completed_education'
colnames(m_demo3)[7] <- 'level_education'

demog <-m_demo3

demog$sex <- as.factor(demog$sex)
demog$age <- as.integer(demog$age)
demog$`completed_education` <- as.factor(demog$`completed_education`)
demog$`level_education` <- as.factor(demog$`level_education`)
demog$`normal_vision` <- as.factor(demog$`normal_vision`)
demog$`normal_hearing` <- as.factor(demog$`normal_hearing`)

levels(demog$sex) <- c('Male', 'Female')
levels(demog$`normal_vision`) <-  c('No', 'Yes')
levels(demog$`normal_hearing`)<-  c('No')
levels(demog$`completed_education`) <-  c('Yes', 'No')
levels(demog$`level_education`) <- c('Secondary School', 'Third Level or higher')

demographic_summary <-demog %>%
  group_by(ID, sex) %>%
  summarise(age= age)

#pps details - demographics
mean(demog$age)
sd(demog$age)
summary(demog$sex)
summary(demog$`completed_education`)
summary(demog$`level_education`)
summary(demog$`normal_vision`)
summary(demog$`normal_hearing`)

demographics <- demographic %>%
  group_by(ID) %>%
  summarise(mean_age= mean (age),
            mean_gender= mean (sex))
table(demographics$mean_gender)
mean(demographics$mean_age)
sd(demographics$mean_age)

#clean dataset - select  relevant variables for TASK 1 & 2
cols<- c('participant', 'Resp_k', 'Label', 'withinCat', 'slider.response', 'corrAns1','slider.rt', 'slider_2.response','corrAns2','slider_2.rt')
id_task <- merged[cols]
#remove duplicate columns and NA columns 
id_task2 <- id_task[!duplicated(id_task), ]
id_task3 <- id_task2[complete.cases(id_task2),]
levels(id_task3$participant)             
id_task3$version <- ifelse(demog$ID %in% c("5598528afdf99b38e56c8c0d","5b257364a7cee100011d8831", "5bfd7019881c6f0001d7a9fa","5c708c40b2da8a0001ee06c5",
                                                   "5cf765f7b026f40001fe1bc6","5d332ea34007ad00199c3713", "5e1dc69010cb38000cbe3343" ,"5ec9288c8ec8f804d6809d9b",
                                                   "5fd6744da6778c581ec7bcef" ,"60206310ea41df674fec540a","6167116fd8a186cd98501614", "63065efb0681721b139af9a0",
                                                   "637be9ed8005fb3ac639e04f", "6381d962851cf5727b98a073", "63d14a5169cba7f13b867c4b" ,"64412176f816c39534d16bf0"), 'label', 'images')
#assign correct answer if the participant response correspond to the correct one
id_task3$accuracy1L<- ifelse(id_task3$slider.response == id_task3$corrAns1, '1','0')
id_task3$accuracy2L<- ifelse(id_task3$slider_2.response == id_task3$corrAns2, '1','0')

id_task3$accuracy1L <- as.integer(id_task3$accuracy1L)
id_task3$accuracy2L <- as.integer(id_task3$accuracy2L)

#accuracy task 1 & 2
cols0 <- c('participant', 'Resp_k', 'version', 'Label', 'withinCat', 'accuracy1L', 'slider.rt','accuracy2L', 'slider_2.rt')
task12 <- id_task3[cols0]
task12$Label <- as.factor(task12$Label)
levels(task12$Label)
colnames(task12)[1] <- "ID"
colnames(task12)[3] <- "Version_t2"
colnames(task12)[4] <- "object_class"
colnames(task12)[5] <- "object_name"
colnames(task12)[6] <- "accuracy1L"
colnames(task12)[7] <- "RT_1L"
colnames(task12)[8] <- "accuracy2L"
colnames(task12)[9] <- "RT_2L"

full_dataset <- merge(demog, task12, by = 'ID')
colnames(full_dataset)[8] <- "correct response"
colnames(full_dataset)[9] <- "version"
full_dataset$RTms_1L <-full_dataset$RT_1L *1000
full_dataset$RTms_2L <-full_dataset$RT_2L *1000
write.table(full_dataset, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOCOS-sound\\analysis_nov2023\\full_dataset.csv",  sep= ",")
list(full_dataset)

#task1
cols1 <- c('ID', 'correct.response', 'object_class', 'object_name', 'accuracy1L', 'RTms_1L')
task1 <- full_dataset[cols1]
task1$object_class <- as.factor(task1$object_class)
levels(task1$object_class)


#outliers removal - RTs and cut off (#a,#b,#c)
  #a - cut_off for outliers for overall group, here at least 3 SDs above the mean 
  upper_cut_off <- mean(task1$RTms) + 3*(sd(task1$RTms))
  upper_cut_off
  lower_cut_off <- mean(task1$RTms) - 3*(sd(task1$RTms))
  lower_cut_off
  taks1_gc <- subset(task1, RTms < upper_cut_off & RTms > lower_cut_off)
  
  #b - cut-off for outliers per person, based on their own mean and SD, here at least 4 SDs above the mean
  taks1_ic<- taks1_gc %>% 
    group_by(ID) %>%
    filter(RTms < mean(RTms) + (4 * sd(RTms)), RTms > mean(RTms) - (4 * sd(RTms)))
  taks1_ic
  
  boxplot(taks1_ic$RTms)
  hist(taks1_ic$RTms)
  range(taks1_ic$RTms)
  
  #c - check people with RT below 500 ms 
  below500 <- subset(taks1_ic, RTms <500)
  summary(below500)
  taks1_ic<- subset(taks1_ic, ID != '63d14a5169cba7f13b867c4b')
  
means_task1<- taks1_ic %>%
  group_by(object) %>%
  summarise(mean_acc= mean (accuracy1L),
            mean_sd = sd(accuracy1L),
            mean_RT= mean(RTms),
            sd_RT= sd(RTms))
means_task1
write.table(means_task1, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOCOS-sound\\analysis_nov2023\\accuracy1task.csv",  sep= ",")

task1_class = taks1_ic %>% 
  group_by(ID, object) %>% 
  summarise(
    mean_acc = mean(accuracy1L),
    sd_acc = sd(accuracy1L),
    mean_rt= mean(RTms),
    sd_rt = sd(RTms))
task1_class

#check data distribution and plot frequency/count of trials and PLOT IT
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOCOS-sound\\analysis_nov2023")
dev.off()

table(task1_class$mean_acc)
task1_class$mean_acc <- as.factor(task1_class$mean_acc)
plot(task1_class$mean_acc~task1_class$object, data= task1_class)
levels(task1_class$mean_acc)

task1_class$chance <- ifelse(task1_class$mean_acc %in% c("0", "0.25"), "Below chance", 
                             ifelse(task1_class$mean_acc %in% c("0.5"), "At chance", "Above chance"))

table(task1_class$chance[task1_class$object == 'Bell'])

frequency_accuracy1 <- ggplot(task1_class, aes(x = object, fill = chance)) + 
  geom_bar(position = 'dodge') + 
  scale_fill_manual(values = c("olivedrab", "#E7B800", "darkred"))+
  scale_y_continuous(limits = c(0,31)) +
  #geom_text(aes(label=..count..),stat = "count")+
  theme_clean()+
  labs(x= "Object",y= "Particpant count (N)",title = "First auditory identification task perfomance")+ 
  theme(legend.title = element_blank(), legend.position = "top")
frequency_accuracy1
ggsave('frequency_accuracy1.jpg', frequency_accuracy1, width = 10, height = 5, dpi = 300)

#plot the proportions / percentage - ?

#plots exploratory and means
task1_acc_means2<- ggboxplot(means_task1, x = "object", y = "mean_acc",color = "object", palette =  c("#00AFBB", "#E7B800", "#FC4E07", 'green')) +
  theme_minimal()
task1_acc_means2
#plot accuracy means
task1_acc_means<- ggplot(data = means_task1, aes(x=object, y = mean_acc, fill= object))+
  #geom_errorbar(aes(ymin = mean_acc, ymax = mean_acc + mean_sd), width=.2,position=position_dodge(.9))+
  geom_bar(stat = 'identity') +
  #geom_point(size = 4.5, col = c("#00AFBB", "#E7B800", "#FC4E07", 'green'))+ for points
  scale_fill_manual(values = c("lightblue", "purple", "orange", 'lightgreen'))+
  coord_cartesian(ylim = c(0,1))+
  geom_hline(yintercept = 0.5, linetype = 'dashed', col = 'black')+
  theme_clean(base_size=15)+ theme(legend.position = 'bottom') 
task1_acc_means
ggsave('task1_acc_means.jpg', task1_acc_means, width = 5, height = 3, dpi = 300)

#reaction times
task1_RT<-ggplot(data = task1_class, aes(x = object, y = mean_rt, col=object))+
  geom_point()+
  geom_boxplot()+
  scale_color_manual(values = c("#00AFBB", "#E7B800", "darkred", 'olivedrab'))+
  theme_minimal(base_size=10)+
  coord_cartesian(ylim = c(0,8000))+
  theme_clean()+
  labs(x= "Object",y= "Reaction times",title = "First auditory identification task perfomance reaction times")+ 
  theme(legend.title = element_blank(), legend.position = "top")
task1_RT
ggsave('task1_RT.jpg', task1_RT, width = 10, height = 5, dpi = 300)

#task accuracy 2
cols2 <- c('ID', 'correct.response', 'version', 'object_class', 'object_name', 'accuracy2L', 'RTms_2L')
task2 <- full_dataset[cols2]
task2$object_class <- as.factor(task2$object_class)
levels(task2$object_class)

task2$object <- as.factor(task2$object)
task2$object_name<- as.factor(task2$object_name)
task2$version <- as.factor(task2$version)
task2$accuracy2L <- as.integer(task2$accuracy2L)
task2$RTms <- as.integer(task2$RTms_2L)

#outliers removal - RTs and cut off (#a,#b,#c)
#a - cut_off for outliers for overall group, here at least 3 SDs above the mean 
upper_cut_off <- mean(task2$RTms) + 3*(sd(task2$RTms))
upper_cut_off
lower_cut_off <- mean(task2$RTms) - 3*(sd(task2$RTms))
lower_cut_off
task2_gc <- subset(task2, RTms < upper_cut_off & RTms > lower_cut_off)

#b - cut-off for outliers per person, based on their own mean and SD, here at least 4 SDs above the mean
task2_ic<- task2_gc %>% 
  group_by(ID) %>%
  filter(RTms < mean(RTms) + (4 * sd(RTms)), RTms > mean(RTms) - (4 * sd(RTms)))
task2_ic

boxplot(task2_ic$RTms)
hist(task2_ic$RTms)
range(task2_ic$RTms)

#c - check people with RT below 500 ms 
below500 <- subset(task2_ic, RTms <500)
summary(below500)

means_task2<- task2_ic %>%
  group_by(version,object_class,object_name) %>%
  summarise(mean_acc= mean (accuracy2L),
            mean_sd = sd(accuracy2L),
            mean_RT= mean(RTms),
            sd_RT= sd(RTms))
means_task2
write.table(means_task2, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOCOS-sound\\analysis_nov2023\\accuracy2task.csv",  sep= ",")

task2_object = full_dataset %>% 
  group_by(version, object_class,object_name) %>% 
  summarise(
    mean_acc = mean(accuracy2L),
    sd_acc = sd(accuracy2L),
    mean_rt= mean(RTms_2L),
    sd_rt = sd(RTms_2L))
task2_object

#check data distribution and plot frequency/count of trials and PLOT IT
table(task2_object$mean_acc)
task2_object$mean_acc <- as.factor(task2_object$mean_acc)
plot(task2_object$mean_acc~task2_object$object_name, data= task2_object)
levels(task2_object$mean_acc)

task2_object$chance <- ifelse(task2_object$mean_acc < 0.5, "Below chance", 
                              ifelse(0.5 <= task2_object$mean_acc & task2_object$mean_acc <= 0.54, "At chance", "Above chance"))

frequency_accuracy2 <- ggplot(task2_object, aes(x = object_name, fill = chance)) + 
  geom_bar(position = 'dodge') + 
  facet_wrap(~version)+
  scale_fill_manual(values = c("olivedrab", "#E7B800", "darkred"))+
  scale_y_continuous(limits = c(0,25)) +
  #geom_text(aes(label=..count..),stat = "count")+
  theme_clean()+
  labs(x= "Object exemplar",y= "Participant count (N)",title = "Second auditory identification task perfomance by version")+ 
  theme(legend.title = element_blank(), legend.position = "top",axis.text.x = element_text (angle=45, hjust=1))+
  lims(y = c(0,3))
frequency_accuracy2
ggsave('frequency_accuracy2_byVersion.jpg', frequency_accuracy2, width = 10, height = 5, dpi = 300)

install.packages("RColorBrewer")
library(RColorBrewer)
display.brewer.all()
install.packages("ggplot2")
library(ggplot2)

dev.off()

#plot accuracy means
task2_acc_means<- ggplot(data = means_task2, aes(x = factor(object_name,level=c("ChurchBell","Hand Bell","Coke Bottle","Wine Bottle","Beer Glass","Wine Glass","Single stem Vase","Urn Vase")), y = mean_acc, fill= object_class))+
  #geom_errorbar(aes(ymin = mean_acc, ymax = mean_acc + mean_sd), width=.2,position=position_dodge(.9))+
  geom_bar(stat = 'identity') +
  scale_fill_manual(values = c("#00AFBB", "#E7B800", 'olivedrab', "darkorange"))+
  facet_wrap(~version)+
  #geom_point(size = 4.5, col = c("#00AFBB", "#E7B800", "#FC4E07", 'green'))+ for points
  coord_cartesian(ylim = c(0,1))+
  geom_hline(yintercept = 0.5, linetype = 'dashed', col = 'black')+
  theme_classic()+
  theme(legend.title = element_blank(), legend.position = "top",axis.text.x = element_text (angle=45, hjust=1))+
  labs(x= "Object exemplar",y= "Accuracy",title = "Second auditory identification task perfomance by version")
task2_acc_means
ggsave('task2_acc_means_byVersion.jpg', task2_acc_means, width = 15, height = 8, dpi = 300)

#reaction times
task2_RT<-ggplot(data = task2_object, aes(x = factor(object_name,level=c("ChurchBell","Hand Bell","Coke Bottle","Wine Bottle","Beer Glass","Wine Glass","Single stem Vase","Urn Vase")), y = mean_rt, col=object_class))+
  geom_point(size=4.5)+
  #geom_errorbar(aes(ymin = mean_rt - sd_rt, ymax =mean_rt - sd_rt), width=.5,position=position_dodge(.9))+
  geom_boxplot()+
  facet_wrap(~version)+
  scale_color_manual(values = c("#00AFBB", "#E7B800", 'olivedrab', "darkorange"))+
  theme_minimal(base_size=10)+
  coord_cartesian(ylim = c(0,5000))+
  theme_classic()+
  theme(legend.title = element_blank(), legend.position = "top",axis.text.x = element_text (angle=45, hjust=1))+
  labs(x= "Object exemplar",y="Reaction times",title = "Second auditory identification task perfomance reaction times")
task2_RT
ggsave('task2_RT_byVersion.jpg', task2_RT, width = 12, height = 6, dpi = 300)

###data anaysis#####
#for models
library(lme4)
library(emmeans)
library(afex)
library(nloptr)
library(optimx)

##check overall discrimination perfomance ~LC
full_dataset$sex <- as.factor(full_dataset$sex)
full_dataset$age <- as.numeric(full_dataset$age)
full_dataset$nTrials1 <- 4
full_dataset$nTrials2 <- 2

#task1
glmer1 <- glmer(accuracy1L ~ age + sex + object_class+ RTms_1L + object_name*RTms_1L +
                  (1|ID), 
                data = full_dataset,
                family = binomial(link = "logit"), weights = nTrials1, control=glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=2e5)))
summary(glmer1)

glmer1_compare <- glmer(accuracy1L ~ age + sex + object_class+ RTms_1L +
                          (1|ID), 
                        data = full_dataset,
                        family = binomial(link = "logit"), weights = nTrials1, control=glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=2e5)))
summary(glmer1_compare)
anova(glmer1, glmer1_compare)



#task2
glmer2 <- glmer(accuracy2L ~ age + sex + object_class + version + object_class*version +
                  (1|ID), 
                data = full_dataset,
                family = binomial(link = "logit"), weights = nTrials2, control=glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=2e5)))
summary(glmer2)
glmer2_compare <- glmer(accuracy2L ~ age + sex + object_class + version + 
                          (1|ID),
                        data = full_dataset,
                        family = binomial(link = "logit"), weights = nTrials2, control=glmerControl(optimizer="bobyqa", optCtrl=list(maxfun=2e5)))
summary(glmer2_compare)
anova(glmer2, glmer2_compare)

'Data: full_dataset -Models:
glmer2_compare: accuracy2L ~ age + sex + object_class + version + (1 | ID)
glmer2: accuracy2L ~ age + sex + object_class + version + object_class * version + (1 | ID)
               npar    AIC    BIC  logLik deviance  Chisq Df Pr(>Chisq)  
glmer2_compare    8 1412.2 1446.1 -698.08   1396.2                       
glmer2           11 1409.5 1456.1 -693.75   1387.5 8.6741  3    0.03395 *
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1'


'summary(glmer2)
Formula: accuracy2L ~ age + sex + object_class + version + object_class *      version + (1 | ID)
   Data: full_dataset
Weights: nTrials2
     AIC      BIC   logLik deviance df.resid 
  1409.5   1456.1   -693.7   1387.5      501 

Fixed effects:
                                 Estimate Std. Error z value Pr(>|z|)  
(Intercept)                      0.451558   0.388487   1.162   0.2451  
age                             -0.004766   0.007731  -0.616   0.5376  
sexFemale                       -0.189989   0.192780  -0.986   0.3244  
object_classBottle               0.230332   0.256245   0.899   0.3687  
object_classGlass               -0.652774   0.259173  -2.519   0.0118 *
object_classVase                -0.299851   0.255225  -1.175   0.2401  
versionlabel                    -0.400463   0.258661  -1.548   0.1216  
object_classBottle:versionlabel -0.045591   0.367584  -0.124   0.9013  
object_classGlass:versionlabel   0.910349   0.367147   2.480   0.0132 *
object_classVase:versionlabel    0.293855   0.366267   0.802   0.4224  
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

Correlation of Fixed Effects:
            (Intr) age    sexFml objc_B objc_G objc_V vrsnlb obj_B: obj_G:
age         -0.831                                                        
sexFemale   -0.244 -0.019                                                 
objct_clssB -0.345  0.028  0.020                                          
objct_clssG -0.339  0.024  0.027  0.474                                   
objct_clssV -0.340  0.022  0.017  0.483  0.475                            
versionlabl -0.353  0.034  0.039  0.481  0.474  0.481                     
objct_clsB:  0.266 -0.041 -0.032 -0.705 -0.334 -0.341 -0.708              
objct_clsG:  0.260 -0.033 -0.038 -0.338 -0.711 -0.337 -0.705  0.498       
objct_clsV:  0.255 -0.031 -0.023 -0.341 -0.332 -0.703 -0.706  0.500  0.495'